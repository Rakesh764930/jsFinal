<?php
if(!isset($_SESSION))
{
	session_start();
}
?>
<?php
if(!isset($_SESSION["uname"]))
	{
		header("location:error.php");
	}

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="css/home.css">


    <!--bootstrap reference from https://getbootstrap.com/docs/4.4/getting-started/introduction/-->
    <link rel="stylesheet" href="bootstrap/bootstrap/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name= "viewport" content="width=device-width , initial-scale=1.0">
    <title> Lets Buy </title>
<style type="text/css">
.homemsg {
	font-family: Arial, Helvetica, sans-serif;
	color: #009;
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
</style>
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
    require_once("adminmasterpage.php");
	
	?></td>
  </tr>
  <tr>
    <td class="homemsg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="70%" valign="top">&nbsp;</td>
        <td width="30%" align="center">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><h1 align="center">Customer's Feedback</h1></td>
  </tr>
  <tr>
    <td><?php
        
		$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$qry = "select * from feedback";
	$res = mysqli_query($conn,$qry) or die(mysqli_error($conn));
	$cnt = mysqli_affected_rows($conn);
	if($cnt==0)
	{
		print "No feedbacks given by the user";
	}
	else
	{
		print "<table width=100%>
		<tr align='left' bgcolor='#CC3300'>
			 <th>Name</th>
			 <th>emailid</th>
			 <th>Phone</th>
			 <th>rate</th>
			 <th>rate2</th>
			 <th>suggesions</th>
		 </tr>";
		
		while($x=mysqli_fetch_array($res))
		{
			print "<tr bgcolor='#FFFF99'>
				<td>$x[1]</td>
				<td>$x[2]</td>
				<td>$x[3]</td>
				<td>$x[4]</td>
				<td>$x[5]</td>
				<td>$x[6]</td>
			    </tr>";
		}
		print "</table>";
	}
		

	?></td>
  </tr>
</table>
</body>
</html>