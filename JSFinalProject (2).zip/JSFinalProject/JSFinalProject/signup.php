<?php
if(isset($_POST["ckavail"]))
{
	$un=$_POST["username"];
	$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$q = "select name from signup where emailid='$un'";
	mysqli_query($conn,$q) or die(mysqli_error($conn)) ;
	$cnt = mysqli_affected_rows($conn);
	if($cnt==0)
	{
		$msg1 = "Available";	
	}
	else
	{
		$msg1 = "Not Available";	
	}
}

if(isset($_POST["submit"]))
{
$un=$_POST["username"];
	$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$q = "select name from signup where emailid='$un'";
	mysqli_query($conn,$q) or die(mysqli_error($conn)) ;
	$cnt = mysqli_affected_rows($conn);
	if($cnt==0)
	{
	$n = $_POST["name"];
	$add = $_POST["address"];
	$phone = $_POST["contact"];
	$username = $_POST["username"];
	$ct=$_POST["city"];
	$state=$_POST["state"];
	$pass = $_POST["password"];
	$gender = $_POST["gen"];
	$dob=$_POST["day"]."-".$_POST["month"]."-".$_POST["year"];
	
	$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$q = "insert into signup values('$n','$add','$phone','$username','$ct','$state','$pass','$gender','$dob','normal')";
	mysqli_query($conn,$q) or die(mysqli_error($conn)) ;
	header("location:thx.php");
		
}
else
	{
		$msg = "Email ID already in use";	
	}
}

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name= "viewport" content="width=device-width , initial-scale=1.0">
    <title> Lets Buy </title>

  </head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td><?php
	require_once("mainpage.php");
    ?></td>
  </tr>
  <tr>
    <td>  </td>
  </tr>
</table>

<div id="d12">
      <form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
        <h3>SignUp information</h3>
           <br>
          <label for="name"> Username:</label>
            <input type="text" name="username" id="username" />
        <br><label for="address">Password :</label>
            <input type="password" name="password" id="password" /><br>
            <label for="contact"> &nbsp &nbspConfirm:</label>
            <input type="password" name="cpass" id="cpass" /><br>
            <br>
          <h3>Personal information</h3>
                   <label for="username">Full Name:</label>
            <input type="text" name="name" id="name" />
          </br>
            <label for="password"> &nbsp Address : </label>
            <input type="text" name="address" id="address" />
    </br>
    <td><label for="cpass">&nbsp &nbsp Contact:</label>
            <input type="text" name="contact" id="contact" />
    </br>

    <label for="city"> &nbsp &nbsp &nbsp &nbsp &nbsp City:</label>
            <input type="text" name="city" id="city" /></br>
            <label for="state">&nbsp &nbsp &nbsp &nbsp State:</label>
            <input type="text" name="state" id="state" /></br>

          <td>&nbsp &nbsp Gender</td>
          <td><label>
            <input type="radio" name="gen" id="male" value="male" />
            Male</label>
            <label>
              <input type="radio" name="gen" id="female" value="female" />
            Female</label>
            <label>
              <input type="radio" name="gen" id="other" value="other" />
            Other</label>
            <br>
          <td>&nbsp &nbsp D.O.B</td>
          <td><label for="day">
            <select name="day" id="day">
              <option>day</option>
              <?php
			for($i=1;$i<=31;$i++)
			{
				print "<option value='$i'>$i</option>";	
			}
			
			?>
              </select>
            <select name="month" id="month">
              <option>month</option>
              <?php
			for($i=1;$i<=12;$i++)
			{
				print "<option value='$i'>$i</option>";	
			}
			
			?>
              </select>
            <select name="year" id="year">
              <option>year</option>
              <?php
			for($i=1965;$i<=2015;$i++)
			{
				print "<option value='$i'>$i</option>";	
			}
			
			?>
              </select>
            </label><br>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp <input type="submit" name="submit" id="submit" value="Sign up" onclick="return valid()" /><br>
    </form>
    
    </div>

<script type="text/javascript">
function valid()
{
if(document.form1.name.value.length<1)
{
 alert("Please fill proper name")
 return false
 }
if(document.form1.password.value.length<1)
{
 alert("please fill password")
 return false
 }
 if(document.form1.cpass.value.length<1)
{
 alert("please fill  confirm password")
 return false
 }
 var p1,p2
 p1=document.form1.password.value
  p2=document.form1.cpass.value
  if(p1!=p2)
  {
  alert("Password Mismatch")
  return false
  }
  if(document.form1.username.value.length<1)
  {
  alert("please fill email")
  return false
  }
  
  if(document.form1.gen[0].checked==false && document.form1.gen[1].checked==false)
  {
  alert("Choose Gender")
  return false
  }
  
  
  if(document.form1.day.selectedIndex==0|| document.form1.month.selectedIndex==0|| document.form1.year.selectedIndex==0)
  {
  alert("Choose DOB")
  return false
  }
}
</script>

<footer> follow us on :
            <a href="https://www.facebook.com/rakeshkumar" class="fa fa-facebook"></a>
            <a href="https://www.twitter.com/@rakesh25948380" class="fa fa-twitter"></a>
            <a href="https://www.linkedin.com/in/rakesh-kumar-na-b20b45194/" class="fa fa-linkedin"></a>
            <a href="https://www.instagram.com/?hl=en" class="fa fa-instagram"></a><br>

            &copy; Copyright 2020. All Rights Reserved.<br>

      </footer>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script src="https://use.fontawesome.com/3d7be19efc.js"></script>


</body>
</html>