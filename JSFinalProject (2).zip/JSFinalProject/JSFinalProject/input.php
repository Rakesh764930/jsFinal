<html>
<head>
	<title>Input from User</title>
</head>
<body>
<form name="abc" method="get" action="calc.php">
Enter first number <input type="text" name="fno"><br/><br/>
Enter second number <input type="text" name="sno"><br/><br/>
<input type="submit" name="submit" value="Sum">
</form>
</body>
</html>
