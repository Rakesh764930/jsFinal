<?php
if(!isset($_SESSION))
{
	session_start();
}
?>
<?php
if(!isset($_SESSION["uname"]))
	{
		header("location:error.php");
	}

?>
<?php
if(isset($_POST["submit"]))
{
	$oldpass = $_POST["currentpass"];
	$newp = $_POST["newpass"];
	$cnewp = $_POST["cnewpass"];
	if($newp==$cnewp)
	{
		
		$un = $_SESSION["uname"];//reading from the session
		$conn = mysqli_connect("localhost","root","","myprojdbase") 
				or die(mysqli_connect_error());
		$qry = "update signup set password='$newp' where emailid='$un' and password='$oldpass'";
		mysqli_query($conn,$qry);
		$cnt = mysqli_affected_rows($conn);
		if($cnt==0)
		{
			$msg = "Current Password Incorrect";	
		}
		else
		{
			$msg = "Password changed successfully";	
				
		}
	}
	else
	{
		$msg = "New Password doesn't match";	
	}

	
	
}


?>

<!DOCTYPE html >
<html >
<head>
<link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name= "viewport" content="width=device-width , initial-scale=1.0">
    <title> Lets Buy </title>
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
    require_once("mainpage.php");
	?></td>
  </tr>
  </table>
  <div id="d12">
    <form id="form1" name="form1" method="post" action="">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="23%" align="center">Change Password</td>
          <td width="77%">&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>Current Password</td>
          <td><input type="password" name="currentpass" id="currentpass" /></td>
        </tr>
        <tr>
          <td>New Password</td>
          <td><input type="password" name="newpass" id="newpass" /></td>
        </tr>
        <tr>
          <td>Confirm New Password</td>
          <td><input type="password" name="cnewpass" id="cnewpass" /></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><input type="submit" name="submit" id="submit" value="Change Password" /></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><?php
if(isset($_POST["submit"]))
{
	print $msg;	
}
?></table></form></div>
</body>
</html>