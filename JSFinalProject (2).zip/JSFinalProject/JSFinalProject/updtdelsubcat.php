<?php
if(!isset($_SESSION))
{
	session_start();
}
?>
<?php
if(!isset($_SESSION["uname"]))
	{
		header("location:error.php");
	}

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="css/home.css">
    <!--bootstrap reference from https://getbootstrap.com/docs/4.4/getting-started/introduction/-->
    <link rel="stylesheet" href="bootstrap/bootstrap/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name= "viewport" content="width=device-width , initial-scale=1.0">
    <title> Lets Buy </title>
<style type="text/css">
.homemsg {
	font-family: Arial, Helvetica, sans-serif;
	color: #009;
}
</style>
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
    require_once("adminmasterpage.php");
	
	?>
	</td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td valign="top"><div id="d12"><form action="form1" method="post" enctype="multipart/form-data" name="form1" id="form1">
          <table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td><h2 align="center">Update/Delete Sub-Category</h2></td>
              </tr>
            <tr>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td>

        <?php
		$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$qry = "select * from addsubcat";
	$res = mysqli_query($conn,$qry);
	$cnt = mysqli_affected_rows($conn);
	if($cnt==0)
	{
		print " Sub Category not updated";
	}
	else
	{
		print "<table width=100%>";
		print "<tr align='left'>";
			
			print "<th>Sub Category Name</th>";
			print "<th>Picture</th>";
			print"<th>Click to delete/update </th>";
			
		
			print "</tr>";
		$eo=0;
		while($x=mysqli_fetch_array($res))
		
		{
			if($eo==0)
			{
			print "<tr  >";
				
			print "<td>$x[1]</a></td>";
			print "<td>
				<img src='userpics/$x[3]' width='150' height='175'>
			</a>
			</td>";
			print"<td>
					<a href='delsubcat.php?scid=$x[0]' style='text-decoration:none; color:white'>Delete &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</a>
					<a href='updtsubcat.php?scid=$x[0]' style='text-decoration:none; color:white'>Update</a>						
				</td>";
	
			
				
			print "</tr>";
				$eo=1;
			}
		else
		{
			
			print "<tr >";
				print "<td>$x[1]</td>";
			print "<td>
				<img src='userpics/$x[3]' width='150' height='175'>
			</a>
			</td>";
			print"<td>
					<a href='delsubcat.php?scid=$x[0]' style='text-decoration:none; color:white'>Delete &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</a>
					<a href='updtsubcat.php?scid=$x[0]' style='text-decoration:none; color:white'>Update</a>						
				</td>";
			
		$eo=0;
		}
		}
	}
		print "</table>";
		
	
		?>              </td>
		</tr>
	  </table>
	</form></div></td>
	</tr>
</table></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
</table>
</body>
</html>