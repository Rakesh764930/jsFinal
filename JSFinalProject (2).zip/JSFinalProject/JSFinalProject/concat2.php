<?php
if(isset($_GET["sub"]))
{
$s=$_GET["nm"].$_GET["ext"];
header("location:http://www.$s");
}
?>
<html>
	<head>
		<title>concat2</title>
	</head>
	<body>
	<form name="abc" method="get">
	enter the name of website=
	<input type="text" name="nm"><br/>
	<input type="radio" name="ext">.com<br/>
	<input type="radio" name="ext">.in<br/>
	<input type="radio" name="ext">.org<br/>
	<input type="submit" name="sub" value="submit">
	</form>
	</body>
</html>