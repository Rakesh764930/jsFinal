<?php
if(!isset($_SESSION))
{
	session_start();	
}

	$un = $_SESSION["uname"];
	$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$qry="select * from cash where username='$un' order by orderno desc";
	
	$res=mysqli_query($conn,$qry) or die(mysqli_error($conn));
	$count=mysqli_affected_rows($conn);
	$x = mysqli_fetch_array($res);
	
	$orderno = $x[0];
	
	
	
	
	
	$qry="select * from addtocart where username='$un'";
	
	$res1=mysqli_query($conn,$qry) or die(mysqli_error($conn));

	while($x = mysqli_fetch_array($res1))
	{
		$qry="insert into finalorderitems(productname,rate,qty,totalcost,prodpic,username,orderno) values ('$x[1]','$x[2]','$x[3]','$x[4]','$x[5]','$x[6]','$orderno')";
		
		mysqli_query($conn,$qry) or die(mysqli_error($conn));
	}
	
	
	$qry="delete from addtocart where username='$un'";
	
	mysqli_query($conn,$qry) or die(mysqli_error($conn));

	mysqli_close($conn);
	
	


?>







<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.homemsg {
	font-family: Arial, Helvetica, sans-serif;
	color: #009;
}
</style>
</head>

<body>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
    require_once("mainpage.php");
	
	?></td>
  </tr>
  <tr>
    <td><form id="form1" name="form1" method="post" action="">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td><p>Thanks for placing order on our website. </p>
            <p>Your order number is 
            <?php
            
			print $orderno;
			
			?>
			</p>
            <p>Your total bill amount is <?php
            
			print $_SESSION["tbill"];
			
			?>
            </p></td>
        </tr>
      </table>
    </form></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>