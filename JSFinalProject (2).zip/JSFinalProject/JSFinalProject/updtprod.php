<?php
if(!isset($_SESSION))
{
	session_start();
}
?>
<?php
if(!isset($_SESSION["uname"]))
	{
		header("location:error.php");
	}

?>
<?php
$id=$_GET["pid"];
$conn = mysqli_connect("localhost","root","","myprojdbase")
			or die(mysqli_connect_error());
			$qry="select * from addproduct where productid='$id'";
			$res=mysqli_query($conn,$qry);
			$x=mysqli_fetch_array($res);
if(isset($_POST["submit"]))
{
	
    $cname=$_POST["catname"];
    
	$cpic=$_FILES["catpic"]["name"];
	if(empty($cpic))
	{
        $cpic=$x[6];
	}
	else
	{
		$cpic=$_FILES["catpic"]["name"];
	
	$tname = $_FILES["catpic"]["tmp_name"];
	if($_FILES["catpic"]["error"]==0)
	{
		move_uploaded_file($tname,"userpics/$cpic");
	}
	}
	$conn = mysqli_connect("localhost","root","","myprojdbase")
			or die(mysqli_connect_error());
	$qry = "update addproduct set productname='$cname',productpic='$cpic' where productid='$id'";
	$res = mysqli_query($conn,$qry)or die(mysqli_error($conn));
	$cnt = mysqli_affected_rows($conn);
	mysqli_close($conn);
	if($cnt==1)
	{
		$msg=" Product updated successfully..";
	}
	else
	{
		$msg = "Product  did not Updated ";		
	}
}
?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.homemsg {
	font-family: Arial, Helvetica, sans-serif;
	color: #009;
}
.lefthead {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.heading {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: 24px;
}
</style>
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
    require_once("adminmasterpage.php");
	
	?></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td valign="top"><form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
          <table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="20%" class="heading">Update Product</td>
              <td width="80%">&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td class="lefthead">Product Name</td>
              <td><label for="catname"></label>
                <input type="text" name="catname" id="productname" value="<?php
				print "$x[3]";
                ?>"/></td>
            </tr>
            <tr>
              <td class="lefthead"><?php
              print "<img src='userpics/$x[6]' height='100' width='50'";
			  
			  ?>&nbsp;</td>
              <td><label for="catpic"></label>
                <input type="file" name="catpic" id="productpic" /></td>
            </tr>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td><input type="submit" name="submit" id="submit" value="update" /></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td><?php
              if(isset($_POST["submit"]))
			{			
				print $msg;
			}
			  
			  
			  ?></td>
            </tr>
          </table>
        </form></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>