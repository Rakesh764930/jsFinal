<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="css/home.css">


    <!--bootstrap reference from https://getbootstrap.com/docs/4.4/getting-started/introduction/-->
    <link rel="stylesheet" href="bootstrap/bootstrap/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name= "viewport" content="width=device-width , initial-scale=1.0">
    <title> Lets Buy </title>
  </head>
  <body>

<table  width="100%" cellpadding="0" cellspacing="0">
  <tr>
    <td>
      <?php
	require_once("mainpage.php");
	
	?>
    </td>
  </tr>
  <tr> 
    <td><table   cellspacing="0" cellpadding="0">
      <tr>
        <td></td>
      </tr>
    </table></td>
  </tr>
</table>
<!--slider -->

<div class="slider row">

<div id="carouselSlideShow" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselSlideShow" data-slide-to="0" class="active"></li>
    <li data-target="#carouselSlideShow" data-slide-to="1"></li>
    <li data-target="#carouselSlideShow" data-slide-to="2"></li>
    <li data-target="#carouselSlideShow" data-slide-to="3"></li>

  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/banner2.jpg" class="d-block w-100" alt="Still loading" id="i1">
      <div class="carousel-caption d-none d-md-block">
        <h5>Exciting Deals</h5>
      </div>
    </div>
    <div class="carousel-item">
      <img src="userpics/menFashionWallpaper.jpg" class="d-block w-100" alt="Still loading">
      <div class="carousel-caption d-none d-md-block">
        <h4>Best Quality Products</h4>
      </div>
    </div>
    <div class="carousel-item">
      <img src="images/banner4.jpg" class="d-block w-100"  alt="Still loading">
      <div class="carousel-caption d-none d-md-block">
        <h4>Amazing Discounts</h4>
      </div>
    </div>
    <div class="carousel-item">
      <img src="images/en.jpg" class="d-block w-100"  alt="Still loading">
      <div class="carousel-caption d-none d-md-block">
        <h4>Lets Check it Out</h4>
      </div>
    </div>
  </div>
  </div>
  </div>
<meta name="viewport" content="width=device-width, initial-scale=1">

<footer> follow us on :
            <a href="https://www.facebook.com/rakeshkumar" class="fa fa-facebook"></a>
            <a href="https://www.twitter.com/@rakesh25948380" class="fa fa-twitter"></a>
            <a href="https://www.linkedin.com/in/rakesh-kumar-na-b20b45194/" class="fa fa-linkedin"></a>
            <a href="https://www.instagram.com/?hl=en" class="fa fa-instagram"></a><br>
            &copy; Copyright 2020. All Rights Reserved.<br>
      </footer>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script src="https://use.fontawesome.com/3d7be19efc.js"></script>


</body>
</html>