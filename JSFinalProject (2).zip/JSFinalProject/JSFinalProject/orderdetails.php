<?php
if(!isset($_SESSION))
{
	session_start();	
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.homemsg {
	font-family: Arial, Helvetica, sans-serif;
	color: #009;
}
</style>
</head>

<body>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
    require_once("mainpage.php");
	
	?></td>
  </tr>
  <tr>
    <td class="homemsg">Order History</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
	<?php
        $ordno = $_GET["odno"];
		$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$qry = "select * from finalorderitems where orderno='$ordno'";
	$res = mysqli_query($conn,$qry);
	$cnt = mysqli_affected_rows($conn);
	if($cnt==0)
	{
		print "No Items";
	}
	else
	{
		print "<table width=1000>";
		print "<tr>";
			print "<th>Item Picture</th>";
			print "<th>Name</th>";
			print "<th>Rate</th>";
			print "<th>Quantity</th>";
			print "<th>Total Cost</th>";
		print "</tr>";
		
		while($x=mysqli_fetch_array($res))
		{
			print "<tr>";
				print "<td>
				<img src='images/$x[5]' width='100' height='150'></td>";
				print "<td>$x[1]</td>";
				print "<td>$x[2]</td>";
				print "<td>$x[3]</td>";
				print "<td>$x[4]</td>";
				
	
			print "</tr>";
		}
		print "</table>";
	}
		
		
		?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>