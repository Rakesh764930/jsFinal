<?php
if(isset($_POST["sub"]))
{
	$err = $_FILES["myfile"]["error"];
	
		if($err==0)
		{
			$fn = $_FILES["myfile"]["name"];
			$fz = $_FILES["myfile"]["size"];
			$ft = $_FILES["myfile"]["type"];
			$tnm = $_FILES["myfile"]["tmp_name"];
			move_uploaded_file($tnm,"userfiles/$fn");
			$msg = "File uploaded successfully";
		}
		else if($err==4)
		{
			$msg = "Please choose file";
		}
		else
		{
			$msg = "There seems to be some error, please try again";
		}

}


?>
<html><head><title>FileUpload in PHP</title></head>
<body>
<form name="abc" method="post" enctype="multipart/form-data">
Choose file to upload <input type="file" name="myfile"></br>
<input type="submit" name="sub" value="Upload">
</form>
</body>
</html>

<?php
if(isset($_POST["sub"]))
{
	print $msg;
}
