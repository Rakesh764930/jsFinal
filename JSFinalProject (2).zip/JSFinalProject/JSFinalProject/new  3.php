<?php
if (isset($_POST["sub"]))
{
$bill=0;
if (isset($_POST["cb1"]))
{
$bill+=100;
}
if (isset($_POST["cb2"]))
{
$bill+=50;
}
if (isset($_POST["cb3"]))
{
$bill+=20;
}
if (isset($_POST["cb4"]))
{
$bill+=70;
}
if (isset($_POST["cb5"]))
{
$bill+=10;
}
if($bill>200)
{
$discount=(10*$bill)/100;
}
else if($bill>100)
{
$discount=(7*$bill)/100;
}
else if($bill>50)
{
$discount=(5*$bill)/100;
}
$tbill=$bill-$discount;
}
?>
<html>
<head><title>check box food</title></head>
<body>
<form name="abc" method="post">
<input type="checkbox" name="cb1" value="piza">pizza<br/>
<input type="checkbox" name="cb2" value="bur">burger<br/>
<input type="checkbox" name="cb3" value="pep">pepsi<br/>
<input type="checkbox" name="cb4" value="man">manchurian<br/>
<input type="checkbox" name="cb5" value="cof">coffee<br/>
<input type="submit" name="sub" value="total bill"><br/>
<?php
if(isset($_POST["sub"]))
{
	print "Total Bill is Rs.$tbill/-<br/>";
	print"discount is RS.$discount/-";
}
?>
</form>
</body></html>