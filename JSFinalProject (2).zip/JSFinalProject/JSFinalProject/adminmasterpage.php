

<?php
if(!isset($_SESSION))
{
	session_start();
}
?>
<?php
	if(isset($_SESSION["uname"]))
	{
		if($_SESSION["ut"]!="admin")
		{
			header("location:error.php");
		}
	}

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="css/home.css">


    <!--bootstrap reference from https://getbootstrap.com/docs/4.4/getting-started/introduction/-->
    <link rel="stylesheet" href="bootstrap/bootstrap/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name= "viewport" content="width=device-width , initial-scale=1.0">
    <title> Lets Buy </title>
</head>
<body>
<style type="text/css">
.lefthead {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.yjjh {
  
}

.yjjh td {
  background:#FFCC00;
	text-align: center;
}
.yjjh td {
	font-weight: bold;
}
.yjjh td {
	font-family: Arial, Helvetica, sans-serif;
}
.up {
	font-family: Arial, Helvetica, sans-serif;
}
.up {
	font-family: Arial, Helvetica, sans-serif;
  text-align: right;
  background:#B4CDCD;
  height:35px;
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
</style>

<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr class="yjjh"></tr>
    </table>
      <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="100%" bgcolor="#CC3300" class="up">Welcome &nbsp&nbsp
            <?php
	if(isset($_SESSION["n"]))
	{
	    print $_SESSION["n"]; //reading from session
		print "<font color='#FF0000' size='+1' style='color:black;'>(Admin) &nbsp&nbsp</font>";
		print "<a href='changepass.php' style='text-decoration:none'> Change Password &nbsp&nbsp</a>";
		print "<a href='signout.php' style='text-decoration:none'> Signout&nbsp&nbsp</a>";
	}
	else
	{
		print "admin ";	
		print "<a href='signup.php'>Sign Up</a>";
		print "<a href='signin.php'> Login</a>";
	}
	?></td>
        </tr>
        <tr>
          <td><img src="userpics/b12.png" width="100%" height="262" /></td>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFCC00">
            <tr class="yjjh">
              <td width="20%" bgcolor="#FFCC00"><a href="srchuser.php" style='text-decoration:none'>Search User</a></td>
              <td width="20%" bgcolor="#FFCC00"><a href="listofmembers.php" style='text-decoration:none'>Member List</a></td>
              <td width="20%" bgcolor="#FFCC00"><a href="addcategory.php" style='text-decoration:none'>Add Category</a></td>
              <td width="20%" bgcolor="#FFCC00"><a href="addsubcat.php" style='text-decoration:none'>Add Subcategory</a></td>
              <td width="20%" bgcolor="#FFCC00"><a href="addproduct.php" style='text-decoration:none'>Add Product</a></td>

              </tr>
            <tr class="yjjh">
              <td bgcolor="#FFCC00">&nbsp;</td>
              <td bgcolor="#FFCC00">&nbsp;</td>
              <td bgcolor="#FFCC00">&nbsp;</td>
              <td bgcolor="#FFCC00">&nbsp;</td>
              <td bgcolor="#FFCC00">&nbsp;</td>
              <td bgcolor="#FFCC00">&nbsp;</td>
              <td  bgcolor="#FFCC00">&nbsp;</td>
              </tr>
            <tr class="yjjh">
            <td width="20%" bgcolor="#FFCC00"><a href="updtdelcat.php" style='text-decoration:none'>Delete/Update Category</a>

            <td width="20%" bgcolor="#FFCC00"><a href="updtdelsubcat.php" style='text-decoration:none'>Delete/Update Sub-Category</a>

            <td  width="20%" bgcolor="#FFCC00"><a href="delUpdatePro.php" style='text-decoration:none'>Delete/Update Product</a><a href="shwadmnconfed.php"></a></td>

              <td width="20%" bgcolor="#FFCC00"><a href="shwadmnfeedback.php" style='text-decoration:none'>Feedbacks</a></td>
			  <td width="20%" bgcolor="#FFCC00"><a href="admine_vieworders.php" style='text-decoration:none'>View Orders</a><a href="shwadmnconfed.php"></a></td>
              <td bgcolor="#FFCC00">&nbsp;</td> 
              <td bgcolor="#FFCC00">&nbsp;</td>
              <td bgcolor="#FFCC00">&nbsp;</td>
              <td bgcolor="#FFCC00">&nbsp;</td> 
              </tr>
          </table></td>
        </tr>
      </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
    </table></td>
  </tr>
</table>
<p class="yjjh">&nbsp;</p>
</body>
</html>
