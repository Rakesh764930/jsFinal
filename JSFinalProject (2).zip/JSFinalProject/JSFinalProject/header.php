
<style type="text/css">
.sitename {
	font-size: 36px;
}
.links {
	font-family: Arial, Helvetica, sans-serif;
	color: #F00;
}
.clinks {
	font-family: Arial, Helvetica, sans-serif;
}
a
{
	
	text-decoration:none;	
}
body
{
	margin:0;	
}
</style>



<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr bgcolor="#FFE9B9">
    <td align="right" class="clinks">Welcome Guest</td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="37%" align="center" bgcolor="#F3A563" class="sitename">ShoppingWorld.Com</td>
        <td width="63%"><form id="form1" name="form1" method="post" action="">
          <input type="image" name="imageField" id="imageField" src="images/banner.jpg" />
        </form></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr align="center" bgcolor="#FFE9B9" class="links">
        <td width="166"><a href="home.php">Home</a></td>
        <td width="167">About Us</td>
        <td width="166">Products</td>
        <td width="167">Search </td>
        <td width="166">Contact Us</td>
        <td width="167">Feedback</td>
      </tr>
    </table></td>
  </tr>
</table>
<p>&nbsp;</p>
