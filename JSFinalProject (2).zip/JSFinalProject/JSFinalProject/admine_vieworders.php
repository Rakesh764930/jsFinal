<?php
if(!isset($_SESSION))
{
	session_start();
}
?>
<?php
if(!isset($_SESSION["uname"]))
	{
		header("location:error.php");
	}

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="css/home.css">

    <!--bootstrap reference from https://getbootstrap.com/docs/4.4/getting-started/introduction/-->
    <link rel="stylesheet" href="bootstrap/bootstrap/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name= "viewport" content="width=device-width , initial-scale=1.0">
    <title> Lets Buy </title>
<style type="text/css">
.homemsg {
	font-family: Arial, Helvetica, sans-serif;
	color: #009;
}
</style>
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
    require_once("adminmasterpage.php");
	
	?></td>
  </tr>
  <tr>
    <td class="homemsg"><center><h2>Order History</h2></center></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
	<?php
        $un = $_SESSION["uname"];
		$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$qry = "select * from cash";
	$res = mysqli_query($conn,$qry);
	$cnt = mysqli_affected_rows($conn);
	if($cnt==0)
	{
		print "No Orders";
	}
	else
	{
		print "<table width=100%>";
		print "<tr bgcolor='#CC3300'>";
			print "<th><center><h3>Order Number</h3></center></th>";
			print "<th><center><h3>Total Bill</h3></center></th>";
			print "<th><center><h3>Shipping Address</h3></center></th>";
			print "<th><center><h3>Order Details</h3></center></th>";
		print "</tr>";
		
		while($x=mysqli_fetch_array($res))
		{
			print "<tr  bgcolor='#FFFF99'>";
				print "<td><center>$x[0]</center></td>";
				print "<td><center>$x[8]</center></td>";
				print "<td><center>$x[7]</center></td>";
				print "<td>
				<a href='ad_orderdetails.php?odno=$x[0]'><center>View Items<center></a>
					</td>";
	
			print "</tr>";
		}
		print "</table>";
	}
		
		
		?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>