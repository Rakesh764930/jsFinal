<?php
if(isset($_POST["sub"]))
{
$a=$_POST["search"];
header("location:https://www.google.com/images?q=$s");
}
if(isset($_POST["sub1"]))
{
$a=$_POST["search"];
header("location:https://www.google.com/search?q=$s");
}
if(isset($_POST["sub2"]))
{
$a=$_POST["search"];
header("location:https://www.google.com/maps?q=$s");
}
?>
<html>
	<head><title>query string</title></head>
	<body>
	<form name="abc" method="post">
	enter anything to search:
	<input type= "text" name="search">
	<input type= "submit" name="sub" value="images">
	<input type= "submit" name="sub1" value="search">
	<input type= "submit" name="sub2" value="maps">
	</form></body>
</html>