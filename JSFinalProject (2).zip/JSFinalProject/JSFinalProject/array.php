  <?php
$a=array(10,'hello',10.1,20,'abc');
foreach($a as $b)
{
print "$b<br/>";
}