<?php
if(!isset($_SESSION))
{
	session_start();
}
?>
<?php
if(!isset($_SESSION["uname"]))
	{
		header("location:error.php");
	}

?>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
    require_once("adminmasterpage.php");
	
	?></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td valign="top" align="center"><b>List of Members</b></td>
        </tr>
      <tr>
        <td valign="top">&nbsp;</td>
      </tr>
      <tr>
        <td valign="top"><?php
        
		$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$qry = "select * from signup";
	$res = mysqli_query($conn,$qry);
	$cnt = mysqli_affected_rows($conn);
	if($cnt==0)
	{
		print "No Members";
	}
	else
	{
		print "<table width=100%>";
		print "<tr align='left' bgcolor='#CC3300'>";
			print "<th>Name</th>";
			print "<th>Address</th>";
			print "<th>City</th>";
			print "<th>State</th>";
			print "<th>Phone</th>";
			print "<th>User Type</th>";
		print "</tr>";
		
		while($x=mysqli_fetch_array($res))
		{
			print "<tr bgcolor='#FFFF99'>";
				print "<td>$x[0]</td>";
				print "<td>$x[1]</td>";
				print "<td>$x[4]</td>";
				print "<td>$x[5]</td>";
				print "<td>$x[2]</td>";
				print "<td>$x[9]</td>";
			print "</tr>";
		}
		print "</table>";
	}
		
		
		?></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
