<!DOCTYPE >
<html >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="bootstrap/bootstrap/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" href="css/home.css">
<title>Lets Buy</title>
<style type="text/css">
.homemsg {
	font-family: Arial, Helvetica, sans-serif;
	color: #009;
}
</style>
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
    require_once("mainpage.php");
      print "<br><br><br?<br>";

	
	?></td>
  </tr>
  <tr>
    <td class="homemsg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"  align ='center' valign="top">
        <?php
        $scatid = $_GET["scid"];
		//$brid=$_GET["bid"];
		$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$qry = "select * from addproduct where subcategory=$scatid";
	$res = mysqli_query($conn,$qry);
	$cnt = mysqli_affected_rows($conn);
	if($cnt==0)
	{
		print "No Products Available";
	}
	else
	{
		print "<div width=100% style='background:green;'>";
		print "<table width=100% style='background:green;'>";
		print "<tr align = 'center'>";
				   print "<div><h3 align='center'> Products </h3></div><br>";

		
				   $cols=1;
				   print "<tr align = 'center'>";
		while($x=mysqli_fetch_array($res))
		
		{
			if($cols<=2)
			{
				
							print"<td>
			<div class='fluid-container'>
			<div class='row' >
			<div class='col-lg-3 col-md-6 col-sm-12'>
				<div class='card '>
				<a href='proddetails.php?pid=$x[0]'>
				<img src='userpics/$x[6]' class='card-img-top' alt='Wait'></a>
				<div class='card-body'>
					<a href='proddetails.php?pid=$x[0]' class='btn btn-outline-success'>$x[4]</a>
				</div>
				</div>

			</div>
			</div>
			</td>";  
			$cols++;	





			// print "<td>
			// <a href='proddetails.php?pid=$x[0]'>
			// 	<img src='userpics/$x[6]' width='150' height='175'>
			// </a><br>
			// <a href='proddetails.php?pid=$x[0]'>$x[4]</a>
			// </td>";
	
			
				
			}
		else
		{

			
			print"<td>
			<div class='fluid-container'>
			<div class='row' >
			<div class='col-lg-3 col-md-6 col-sm-12'>
				<div class='card '>
				<a href='proddetails.php?pid=$x[0]'>
				<img src='userpics/$x[6]' class='card-img-top' alt='Wait'></a>
				<div class='card-body'>
					<a href='proddetails.php?pid=$x[0]' class='btn btn-outline-success'>$x[4]</a>
				</div>
				</div>

			</div>
			</div>
			</td>";  

			print "<tr  align='center'>";

			// print "<td>
			// <a href='showprod.php?scid=$x[0]'>
			// 	<img src='userpics/$x[6]' width='150' height='175'>
			// </a><br>
			// <a href='showprod.php?pid=$x[0]'>$x[4]</a>
			// </td>";
			
			$cols=1;
		}
		}
	}
		print "</table>";
		print "</div>";

		
	
		?></td>
        <td width="100%" align="center">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>