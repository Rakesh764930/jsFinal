<?php
if (isset($_POST["SUB"]))
{
	$fno=$_POST["fno"];
	$sno=$_POST["sno"];
	$c=$sno+$fno;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="summm.php">
  <table width="374" height="49" border="0">
    <tr>
      <td width="121">enter first no.</td>
      <td width="243"><label for="fno"></label>
      <input type="text" name="fno" id="fno" /></td>
    </tr>
    <tr>
      <td>enter second no.</td>
      <td><label for="sno"></label>
      <input type="text" name="sno" id="sno" /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="sub" id="sub" value="Submit" /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><?php
if (isset($_POST["SUB"]))
{
	print"sum is $c";
}
?>
</td>
    </tr>
  </table>
</form>
</body>
</html>