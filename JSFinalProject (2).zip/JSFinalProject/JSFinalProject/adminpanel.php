<?php
if(!isset($_SESSION))
{
	session_start();

}
?>
<?php
	if(isset($_SESSION["uname"]))
	{
		if($_SESSION["ut"]!="admin")
		{
			header("location:error.php");
		}
	}

?>
<style type="text/css">
.dgd {
	font-family: "Courier New", Courier, monospace;
	font-size: larger;
	text-decoration: underline blink;
	font-weight: bold;
	font-style: italic;
	color: #006;
}
</style>
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td>&nbsp;</td>
</tr>
  <tr>
    <td><?php
	require_once("adminmasterpage.php")
    ?></td>
  </tr>
  <tr>
    <td align="center" class="dgd">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" class="dgd">hi,admin you can manage website here...</td>
  </tr>
</table>
