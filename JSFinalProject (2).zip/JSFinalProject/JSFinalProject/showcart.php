<?php
if(!isset($_SESSION))
{
	session_start();	
}
	
	
	
	
	
?>

<!DOCTYPE html >
<html >
<head>
<link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name= "viewport" content="width=device-width , initial-scale=1.0">
    <title> Lets Buy </title>
<style type="text/css">
.homemsg {
	font-family: Arial, Helvetica, sans-serif;
	color: #009;
}
</style>
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
    require_once("mainpage.php");
	
	?></table>
	<div id="d12">
	<form id="form1" name="form1" method="post" action="">
    <?php
    $un = $_SESSION["uname"];
	$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$qry = "select * from addtocart where username='$un'";
	$res = mysqli_query($conn,$qry) or die(mysqli_error($conn));
	$cnt = mysqli_affected_rows($conn);
	if($cnt==0)
	{
		print "You have no products in your cart, please click continue shopping to add products";	
	}
	else
	{
	print "<table width='100%' style= 'border: 2px solid white;'>
	<tr align='left' style= 'border: 2px solid white;'>
		<th>Picture</th>
		<th>Name</th>
		<th>Rate</th>
		<th>Quantity</th>
		<th>Total Cost</th>
		<th>Click to delete</th>
	</tr>";
	$gt = 0;
	while($x=mysqli_fetch_array($res))
	{
			print "<tr align='left' style= 'border: 2px solid white;'>
					<td><img src='userpics/$x[5]' height=150 width=100 style= 'border: 2px black solid; border-radius:10px; '></td>
					<td>$x[1]</td>
					<td>$x[2]</td>
					<td>$x[3]</td>
					<td>$x[4]</td>
					<td><b><a href='delcart.php?srno=$x[0]' style='color:white;border:1px solid white; border-radius:10px'>Delete</a></b></td>
				   </tr>";
				   $gt=$gt+$x[4];
	}
	print "</table>";
	}
	mysqli_close($conn);
    
    ?>
    </form></div>
  </tr>
  <tr>
    <td>  <?php
     if($cnt!=0)
	{
		print "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspYour Grand Total is $$gt"; 
		$_SESSION["tbill"]=$gt;
	}
	?></td>
	<p align="center" ><a href="checkout.php">checkout</a></p></td>
	
    <td><p align="center" ><a href="showcat.php" >Continue Shopping </a></p>
    
  </tr>
</table>
</body>
<footer> follow us on :
            <a href="https://www.facebook.com/rakeshkumar" class="fa fa-facebook"></a>
            <a href="https://www.twitter.com/@rakesh25948380" class="fa fa-twitter"></a>
            <a href="https://www.linkedin.com/in/rakesh-kumar-na-b20b45194/" class="fa fa-linkedin"></a>
            <a href="https://www.instagram.com/?hl=en" class="fa fa-instagram"></a><br>
            &copy; Copyright 2020. All Rights Reserved.<br>
      </footer>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script src="https://use.fontawesome.com/3d7be19efc.js"></script>

</html>