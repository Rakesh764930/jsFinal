<!DOCTYPE html >
<html >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.homemsg {
  font-family: Arial, Helvetica, sans-serif;
  color: #009;
}
</style>
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
    require_once("mainpage.php");
          print "<br><br><br?<br>";

  ?></td>
  </tr>
  <tr>
    <td class="homemsg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"  align = 'center 'valign="top">


<?php
if(!isset($_SESSION))
{
	session_start();	
}

    $prodid = $_GET["pid"];   
	$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$qry = "select addproduct.productname,addproduct.description,addproduct.rate,addproduct.productpic,addcat.catname,addsubcat.scatname from addproduct,addcat,addsubcat where addproduct.category=addcat.catid and addproduct.subcategory=addsubcat.subcatid and addproduct.productid=$prodid";
	$res = mysqli_query($conn,$qry) or die(mysqli_error($conn));
	$x=mysqli_fetch_array($res);
	mysqli_close($conn);
	if(isset($_POST["submit"]))
	{
		if(isset($_SESSION["uname"]))
		{
		$qt = $_POST["qty"];
		$pname=$x[0];
		$rt = $x[2];
		$tc = $rt*$qt;
		$ppic = $x[3];
		$un = $_SESSION["uname"];
		$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
			
		$qry = "insert into addtocart(productname,rate,quantity,totalcost,prodpic,username) values('$pname','$rt','$qt','$tc','$ppic','$un')";
	$res = mysqli_query($conn,$qry) or die(mysqli_error($conn));
	$x=mysqli_fetch_array($res);
	mysqli_close($conn);
	header("location:showcart.php");
		}
	else
		{
			header("location:signin.php?err=login&pid=$prodid");	
		}
		}
	
?>

<!DOCTYPE html>
<html >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Lets Buy</title>
<style type="text/css">
.homemsg {
	font-family: Arial, Helvetica, sans-serif;
	color: #009;
}
</style>
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
    require_once("mainpage.php");
	
	?></td>
  </tr>
  <tr>
    <td><form id="form1" name="form1" method="post" action="">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="20%" valign="top"> Product Details</td>
          <td width="16%" align="center">&nbsp;</td>
          <td width="64%" align="center">&nbsp;</td>
        </tr>
        <tr>
          <td valign="top">&nbsp;</td>
          <td align="center">&nbsp;</td>
          <td align="center">&nbsp;</td>
        </tr>
        <tr>
          <td rowspan="6" align="center" valign="middle"><?php print "<img src='userpics/$x[3]' height=150 width=115>"; ?></td>
          <td valign="top">Product Name</td>
          <td align="left"><?php print $x[0]; ?></td>
        </tr>
        <tr>
          <td valign="top">Category</td>
          <td align="left"><?php print $x[4]; ?></td>
        </tr>
        <tr>
          <td valign="top">Sub Category</td>
          <td align="left"><?php print $x[5]; ?></td>
        </tr>
        
        <tr>
          <td valign="top">Description</td>
          <td align="left"><?php print $x[1]; ?></td>
        </tr>
        <tr>
          <td valign="top">Rate</td>
          <td align="left"><?php print "$ $x[2]"; ?></td>
        </tr>
        <tr>
          <td align="center" valign="middle">&nbsp;</td>
          <td valign="top">quantity</td>
          <td align="left"><label for="qty"></label>
            <input type="text" name="qty" id="qty" /></td>
        </tr>
        <tr>
          <td align="center" valign="middle">&nbsp;</td>
          <td valign="top">&nbsp;</td>
          <td align="left"><input type="submit" name="submit" id="submit" value="add to cart" /></td>
        </tr>
      </table>
    </form></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>