<?php
if(!isset($_SESSION))
{
	session_start();
}
?>
<?php
if(!isset($_SESSION["uname"]))
	{
		header("location:error.php");
	}

?>
<?php
if(isset($_POST["submit"]))
{
	$catnm=$_POST["cname"];
	$pic=$_FILES["cpic"]["name"];
	$tname = $_FILES["cpic"]["tmp_name"];
	if($_FILES["cpic"]["error"]==0)
	{
		move_uploaded_file($tname,"userpics/$pic");
	}
	$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$qry = "insert into addcat(catname,catpic)values('$catnm','$pic')";
	$res = mysqli_query($conn,$qry);
	$cnt = mysqli_affected_rows($conn);
	mysqli_close($conn);
	if($cnt==1)
	{
		$msg = "Category added successfully";	
	}
	else
	{
		$msg = "Category not added successfully";		
	}
}

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="css/home.css">
    <!--bootstrap reference from https://getbootstrap.com/docs/4.4/getting-started/introduction/-->
    <link rel="stylesheet" href="bootstrap/bootstrap/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name= "viewport" content="width=device-width , initial-scale=1.0">
    <title> Lets Buy </title>
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  
  <tr>
    <td><?php
	require_once("adminmasterpage.php");
    ?></td>
  </tr>
  
  <tr>
    <td><h3 align="center">ADD CATEGORY</h3></td>
  </tr>
  
  <tr>
    <td><div id="d12">	
      <form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
      <table width="100%" border="0" cellspacing="0" cellpadding="0"><br>
        <tr>
          <td width="148">Category name</td>
          <td width="852"><label for="cname"></label>
            <input type="text" name="cname" id="cname" /></td>
        </tr>
        <tr>
          <td>Category pic</td>
          <td><label for="cpic"></label>
            <input type="file" name="cpic" id="cpic" /></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><input type="submit" name="submit" id="submit" value="add category" /></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><?php
              if(isset($_POST["submit"]))
			{			
				print $msg;
			}
			?></td>
        </tr>
      </table>
    </form></div></td>
  </tr>
</table>
</body>
</html>