<?php
	$un = $_GET["un"];
	$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$qry = "select * from signup where emailid='$un'";
	$res = mysqli_query($conn,$qry);
	$x = mysqli_fetch_array($res);
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name= "viewport" content="width=device-width , initial-scale=1.0">
    <title> Lets Buy </title>
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
    require_once("adminmasterpage.php");
	?></td>
  </tr>
  <tr>
    <td><div id="d12">
      <form id="form1" name="form1" method="get" action="">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="10%">Name:</td>
          <td width="90%"><?php
          
		  print $x[0];
		  
		  ?></td>
        </tr>
        <tr>
          <td>Address:</td>
          <td><?php
          
		  print $x[1];
		  
		  ?></td>
        </tr>
        <tr>
          <td>City:</td>
          <td><?php
          
		  print $x[4];
		  
		  ?></td>
        </tr>
        <tr>
          <td>State:</td>
          <td><?php
          
		  print $x[5];
		  
		  ?></td>
        </tr>
        <tr>
          <td>Phone:</td>
          <td><?php
          
		  print $x[2];
		  
		  ?></td>
        </tr>
      </table>
    </form></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>