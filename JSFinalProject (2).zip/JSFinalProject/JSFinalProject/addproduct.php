<?php
if(!isset($_SESSION))
{
	session_start();
}
?>
<?php
if(!isset($_SESSION["uname"]))
	{
		header("location:error.php");
	}

?>
<?php
if(isset($_POST["submit"]))
{
	$cat=$_POST["cat"];
	$subcat = $_POST["subcat"];
	$prodname = $_POST["catname"];
	$desc = $_POST["desc"];
	$rate = $_POST["rate"];
	$productpic=$_FILES["catpic"]["name"];
	$tname = $_FILES["catpic"]["tmp_name"];
	if($_FILES["catpic"]["error"]==0)
	{
		move_uploaded_file($tname,"images/$productpic");
	}
	$conn = mysqli_connect("localhost","root","","myprojdbase")
			or die(mysqli_connect_error());
	$qry = "insert into addproduct(category,SubCategory,ProductName,Description,Rate,ProductPic) values('$cat','$subcat','$prodname','$desc','$rate','$productpic')";
	$res = mysqli_query($conn,$qry)or die(mysqli_error($conn));
	$cnt = mysqli_affected_rows($conn);
	mysqli_close($conn);
	if($cnt==1)
	{
		$msg = "Product added successfully";	
	}
	else
	{
		$msg = "Product not added successfully";		
	}
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="css/home.css">


    <!--bootstrap reference from https://getbootstrap.com/docs/4.4/getting-started/introduction/-->
    <link rel="stylesheet" href="bootstrap/bootstrap/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name= "viewport" content="width=device-width , initial-scale=1.0">
    <title> Lets Buy </title>
<style type="text/css">
.homemsg {
	font-family: Arial, Helvetica, sans-serif;
	color: #009;
}
.lefthead {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.heading {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: 24px;
}
</style>
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
    require_once("adminmasterpage.php");
	
	?></td>
  </tr>
  <tr>
    <td>
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td valign="top">	<div id="d12">	

			<form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
          <table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="25%" class="heading" align="center">Add Product</td>
              <td width="75%">&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td class="lefthead">Choose Category:</td>
              <td><label for="cat"></label>
                <select name="cat" id="cat">
                  <option>Select</option>
                  <?php
          $conn = mysqli_connect("localhost","root","","myprojdbase")
    		or die(mysqli_connect_error());
		$qry = "select * from addcat";
		$res = mysqli_query($conn,$qry)or die(mysqli_error($conn));
		$cnt = mysqli_affected_rows($conn);
		if($cnt==0)
		{
			print "<option>No Categories Added</option>";
		}
		else
		{
			while($x = mysqli_fetch_array($res))
			{
				if(isset($_POST["showsubcat"]))
				{
					$catid=$_POST["cat"];
					
					if($x[0]==$catid)
					{
					print "<option value='$x[0]' selected='selected'>$x[1]</option>";
					}
					else
					{
						print "<option value='$x[0]'>$x[1]</option>";
					}
				}
				else
				{
					print "<option value='$x[0]'>$x[1]</option>";
				}
			}
		}
		mysqli_close($conn);
          
          
          ?>
                </select>
                <input type="submit" name="showsubcat" id="showsubcat" value="Go" /></td>
            </tr>
            <tr>
              <td class="lefthead">Choose Sub Category:</td>
              <td><label for="subcat"></label>
                <select name="subcat" id="subcat">
                <option>Select</option>
	  <?php
      if(isset($_POST["showsubcat"]))
      {
		  $catid=$_POST["cat"];
		   $conn = mysqli_connect("localhost","root","","myprojdbase")
			or die(mysqli_connect_error());
		$qry = "select * from addsubcat where maincatid=$catid";
		$res = mysqli_query($conn,$qry)or die(mysqli_error($conn));
		$cnt = mysqli_affected_rows($conn);
		if($cnt==0)
		{
			print "<option>No SubCategories Added</option>";
		}
		else
		{
			while($x = mysqli_fetch_array($res))
			{
				print "<option value='$x[0]'>$x[1]</option>";
			}
		}
 	}
	
          
          
          ?>
                </select></td>
            </tr>
                </select></td>
            </tr>
            <tr>
              <td class="lefthead">Product  Name:</td>
              <td><label for="catname"></label>
                <input type="text" name="catname" id="catname" /></td>
            </tr>
            <tr>
              <td class="lefthead">Description:</td>
              <td><label for="desc"></label>
                <textarea name="desc" id="desc" cols="45" rows="5"></textarea></td>
            </tr>
            <tr>
              <td class="lefthead">Rate:</td>
              <td><label for="rate"></label>
                <input type="text" name="rate" id="rate" /></td>
            </tr>
            <tr>
              <td class="lefthead">Product Picture:</td>
              <td><label for="catpic"></label>
                <input type="file" name="catpic" id="catpic" /></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td><input type="submit" name="submit" id="submit" value="Add Product" /></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td><?php
              if(isset($_POST["submit"]))
			{			
				print $msg;
			}
			  
			  
			  ?></td>
            </tr>
          </table>
		</form></div>
	</td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
