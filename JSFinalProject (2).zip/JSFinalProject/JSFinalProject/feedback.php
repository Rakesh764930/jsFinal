<?php

if(isset($_POST["submit"]))
{	
	$nm=$_POST["name"];
	$nm1=$_POST["mail"];
	$nm2=$_POST["phone"];
	$nm3=$_POST["gen"];
	$nm4=$_POST["gp2"];
	$nm6=$_POST["sugestions"];
	$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$qry = "insert into feedback (name,username,phoneno,rate,rate2,suggessions) values('$nm','$nm1','$nm2','$nm3','$nm4','$nm6')";
 mysqli_query($conn,$qry) or die(mysqli_error($conn));
	$cnt = mysqli_affected_rows($conn);
	if($cnt==1)
	{
		$msg =" Thank You for your feedback!";
	}
	else
	{
		$msg="form not submitted";
	}
}

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="css/home.css">


    <!--bootstrap reference from https://getbootstrap.com/docs/4.4/getting-started/introduction/-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name= "viewport" content="width=device-width , initial-scale=1.0">
    <title> Lets Buy </title>
  </head>

<body >
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
	
	require_once("mainpage.php");
    
	
	?></td>
  </tr>
  <tr>
    <td>
</td>
  </tr>
</table>
<div id="d12">
<form id="form1" name="form1"method="post" action="" ><b>
        <h1 id="h11" >Let us know, How we did today!</h1><br>
          <label for="name">Name :</label>
            <input type="text" name="name" id="name" /><br>
          <label for="mail">E-mail:</label>
            <input type="text" name="mail" id="mail" /><br>
          <label for="phone">Phone:</label>
            <input type="text" name="phone" id="phone" /><br>
       <p> How would you rate our website?</b></p><input type="radio" name="gen" value="Excellent" id="RadioGroup1_4" />
            Excellent</label>
            <br>
            <label>
              <input type="radio" name="gen" value="Moderate" id="RadioGroup1_6" />
              Moderate</label>
            <br />
            <label>
              <input type="radio" name="gen" value="Bad" id="RadioGroup1_7" />
            Bad</label><br><br>
            <b>
            <p>Quality of products</p></b>
              <label>
            <input type="radio" name="gp2" value="Good" id="RadioGroup2_2" />
            Good</label>
            <br />
            <label>
              <input type="radio" name="gp2" value="Average" id="RadioGroup2_3" />
            Average</label><br>
            <label>
              <input type="radio" name="gp2" value="Bad" id="RadioGroup2_3" />
            Bad</label><br>
        <label for="sugestions"><b>Comments</b></label>
            <textarea name="sugestions" id="sugestions" cols="45" rows="3"></textarea>
          <td><input type="submit" name="submit" id="submit" value="Submit" /></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><?php
if(isset($_POST["submit"]))
{
	print $msg;
}
?></td>
        </tr>
    </form>
    </div>

<footer> follow us on :
      <a href="https://www.facebook.com/rakeshkumar" class="fa fa-facebook"></a>
      <a href="https://www.twitter.com/@rakesh25948380" class="fa fa-twitter"></a>
      <a href="https://www.linkedin.com/in/rakesh-kumar-na-b20b45194/" class="fa fa-linkedin"></a>
      <a href="https://www.instagram.com/?hl=en" class="fa fa-instagram"></a><br>
      &copy; Copyright 2020. All Rights Reserved.<br>
</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script src="https://use.fontawesome.com/3d7be19efc.js"></script>


</body>
</html>