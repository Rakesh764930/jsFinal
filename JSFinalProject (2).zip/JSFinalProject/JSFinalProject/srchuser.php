<?php
if(!isset($_SESSION))
{
	session_start();
}
?>
<?php
if(!isset($_SESSION["uname"]))
	{
		header("location:error.php");
	}

?>
<?php
if(isset($_GET["submit"]))
{

	$un = $_GET["un"];
	$conn = mysqli_connect("localhost","root"," ","myprojdbase") 
			or die(mysqli_connect_error());
	$qry = "select * from signup where emailid='$un'";
	$res = mysqli_query($conn,$qry);
	
	//$cnt = mysqli_affected_rows($conn);
	
	$x = mysqli_fetch_array($res);
	
}


?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name= "viewport" content="width=device-width , initial-scale=1.0">
    <title> Lets Buy </title>
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
    require_once("adminmasterpage.php");
	?></td>
  </tr>
  <tr>
    <td><div id="d12"><form action="results.php" method="get" name="form1" id="form1">
      
          <h3>Search User</h3><br>
        
          Enter Username:
          <input type="text" name="un" id="un" /><br>
          &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="submit" name="submit" id="submit" value="Search" /></td>
        
    </form><div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>