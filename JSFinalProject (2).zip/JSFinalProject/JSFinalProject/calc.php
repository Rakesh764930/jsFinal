<?php
$a = $_GET["fno"];
$b = $_GET["sno"];
$c=$a+$b;

print "First number is $a<br/>";
print "Second number is $b<br/>";
print "Sum is $c<br/>";

?>