<?php
if(isset($_GET["sub"]))
{
if(isset($_GET["ms"]) && isset($_GET["g"]))
{
$age=$_GET["age"];
$marital=$_GET["ms"];
$gen=$_GET["g"];
if($marital=="ma")
{
$msg="person is insured";
}
else if( $marital=="unm" and $gen=="m" and $age>30)
{
$msg="person is insured";
}
else if( $marital=="unm" and $gen=="f" and $age>25)
{
$msg="person is insured";
}
else
{
$msg="person is not insured";
}
}
else
{
$msg="please choose all options";
}
}
?>
<html>
<head><title>radio button asignment</title></head>
<body>
<form name="abc" method="get">
enter name:<input type="text" name="nm"><br/><br/>
enter age:<input type="text" name="age"><br/><br/>
choose gender:
<input type="radio" name="g" value="m">male
<input type="radio" name="g" value="f">female<br/><br/>
choose maritAL status:
<input type="radio" name="ms" value="ma">married
<input type="radio" name="ms" value="unm">unmarried<br/><br/>
<input type="submit" name="sub" value="submit"><br/><br/>
<?php
if(isset($_GET["sub"]))
{
print $msg;
}
?>
</form>
</body>
</html>