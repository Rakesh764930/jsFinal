<?php
if(!isset($_SESSION))
{
	session_start();
}
?>
<style type="text/css">
.class1 {
	font-family: Arial, Helvetica, sans-serif;
	color: white;

}
.t1{
	color: white;
}
.hdg {
	font-family: Verdana, Geneva, sans-serif;
}
a{
	color: white;

}
</style>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name= "viewport" content="width=device-width , initial-scale=1.0">
    <title> Lets Buy </title>

  </head>
<table  width="100%"cellpadding="0" cellspacing="0">
  <tr>
    <td align="right" bgcolor="#B4CDCD"><p class="hdg">WELCOME &nbsp
      <?php
	if(isset($_SESSION["n"]))
	{
		$un = $_SESSION["uname"];
		$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$qry = "select * from addtocart where username=' $un'";
	$res = mysqli_query($conn,$qry) or die(mysqli_error($conn));
	$cnt = mysqli_affected_rows($conn);
	    print $_SESSION["n"]; //reading from session &nbsp
		echo '<a href="orderhistory.php" style="color:black;"> &nbsp&nbsp  &nbsp &nbsp Order History  &nbsp &nbsp </a>';
		if($cnt>0)
		{
			echo '<a href="showcart.php" style="color:black;> Show Cart($cnt products)  &nbsp</a>';			
		}
	}
	else
	{
		echo "  Guest &nbsp &nbsp &nbsp";	
		echo '<a href="signup.php" style="color:black; text-decoration:none">SignUp</a> &nbsp';
		print '<a href="signin.php" style="color:black; text-decoration:none"> Login</a> &nbsp&nbsp';
	}
	
	?>
    </p></td>
  </tr>
  <tr>
    <td>
		<table width="100%"  cellspacing="0" cellpadding="0" id="t123" bgcolor="#B4CDCD">
      <tr valign="top" class="class1" >
	  <td   class="t1"><input type="text" placeholder="Search.." id="un"><button>Go</button></td>

		<td   class="t1"><a style="color:black" href="homenew.php">Home</a></td>
        
		<td   class="t1">
		&nbsp &nbsp &nbsp &nbsp

			<a style="color:black" href="showcat.php"> Categories</a></td>


        <td  class="t1">
		&nbsp &nbsp &nbsp &nbsp
			<a style="color:black" href="contactus.php"> Contact Us</a></td>
        <td  class="t1">
		&nbsp &nbsp &nbsp &nbsp
			<a style="color:black" href="feedback.php">Feedback </a>
			&nbsp &nbsp &nbsp &nbsp
		</td>
		<td ><?php
		if(isset($_SESSION["n"]))
	{
		$un = $_SESSION["uname"];
		$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$qry = "select * from addtocart where username='$un'";
	$res = mysqli_query($conn,$qry) or die(mysqli_error($conn));
	$cnt = mysqli_affected_rows($conn);

        echo '<a href="changepass.php" style="color:black; background-color:#B4CDCD;"> Change Password </a> &nbsp&nbsp &nbsp &nbsp';
	}
		?></td>
        <td  class="t1"><?php
		if(isset($_SESSION["n"]))
	{
		$un = $_SESSION["uname"];
		$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$qry = "select * from addtocart where username='$un'";
	$res = mysqli_query($conn,$qry) or die(mysqli_error($conn));
	$cnt = mysqli_affected_rows($conn);
        echo'<a href="signout.php" style="color:black;"> Logout </a> &nbsp&nbsp &nbsp &nbsp';
	}
		?></td>
      </tr>
	</table></td>

  </tr>
</table>

