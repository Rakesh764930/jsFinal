<?php
if(isset($_POST["ckavail"]))
{
	$un=$_POST["emailid"];
	$conn = mysqli_connect("localhost","myprojdbuser","123","myprojdb") 
			or die(mysqli_connect_error());
	$q = "select name from signup where username='$un'";
	mysqli_query($conn,$q) or die(mysqli_error($conn)) ;
	$cnt = mysqli_affected_rows($conn);
	if($cnt==0)
	{
		$msg1 = "Available";	
	}
	else
	{
		$msg1 = "Not Available";	
	}
}


if(isset($_POST["submit"]))
{
	$un=$_POST["emailid"];
	$conn = mysqli_connect("localhost","myprojdbuser","123","myprojdb") 
			or die(mysqli_connect_error());
	$q = "select name from signup where username='$un'";
	mysqli_query($conn,$q) or die(mysqli_error($conn)) ;
	$cnt = mysqli_affected_rows($conn);
	if($cnt==0)
	{
	$n = $_POST["name"];
	$add = $_POST["address"];
	$ct = $_POST["city"];
	$st = $_POST["state"];
	$phone = $_POST["phone"];
	$username = $_POST["emailid"];
	$pass = $_POST["password"];
	$gender = $_POST["gen"];
	$co = $_POST["country"];
	$db = $_POST["day"]."-".$_POST["month"]."-".$_POST["year"];
	$pic = $_FILES["userpic"]["name"];
	
	if($_FILES["userpic"]["error"]==0)
	{
		$tname = $_FILES["userpic"]["tmp_name"];
		move_uploaded_file($tname,"userpics/$pic");
	}
	
	$q = "insert into signup values('$n','$add','$ct','$st','$phone','$username','$pass','$gender','$co','$db','$pic')";
	mysqli_query($conn,$q) or die(mysqli_error($conn)) ;
	header("location:thx.php");
	}
	else
	{
		$msg = "Email ID already in use";	
	}
	
}


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.leftheading {
	font-weight: bold;
	font-family: Arial, Helvetica, sans-serif;
	color: #009;
}
.pageheading {
	color: #F00;
	font-family: Arial, Helvetica, sans-serif;
}
.innedheading {
	color: #A80000;
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
}
</style>
</head>

<body>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
    require_once("header.php");
	
	?></td>
  </tr>
  <tr>
    <td><form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="19%"><h2 class="pageheading">Sign Up</h2></td>
          <td width="46%">&nbsp;</td>
          <td width="35%">&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td bgcolor="#FFFFCC" class="leftheading"><span class="innedheading">Login Information</span></td>
          <td bgcolor="#FFFFCC">&nbsp;</td>
          <td rowspan="10" align="center"><img src="images/sign-up.jpg" width="220" height="211" /></td>
        </tr>
        <tr>
          <td class="leftheading">Email ID(Username)</td>
          <td><input type="text" name="emailid" id="emailid" />
            <input type="submit" name="ckavail" id="ckavail" value="Check Availability" /><?php
            if(isset($_POST["ckavail"]))
			{
				print $msg1;	
			}
			
			?></td>
        </tr>
        <tr>
          <td class="leftheading">Password</td>
          <td><input type="password" name="password" id="password" /></td>
          </tr>
        <tr>
          <td class="leftheading">Confirm Password</td>
          <td><input type="password" name="confirmpass" id="confirmpass" /></td>
        </tr>
        <tr>
          <td bgcolor="#FFFFCC" class="innedheading">Personal Information</td>
          <td bgcolor="#FFFFCC">&nbsp;</td>
        </tr>
        <tr>
          <td class="leftheading">Name</td>
          <td><input type="text" name="name" id="name" /></td>
          </tr>
        <tr>
          <td class="leftheading">Address</td>
          <td><input type="text" name="address" id="address" /></td>
          </tr>
        <tr>
          <td class="leftheading">City</td>
          <td><input type="text" name="city" id="city" /></td>
          </tr>
        <tr>
          <td class="leftheading">State</td>
          <td><input type="text" name="state" id="state" /></td>
          </tr>
        <tr>
          <td class="leftheading">Phone</td>
          <td><input type="text" name="phone" id="phone" /></td>
        </tr>
        <tr>
          <td class="leftheading">Gender</td>
          <td><label><input type="radio" name="gen" id="male" value="male" />
            Male </label>
            <label> <input type="radio" name="gen" id="female" value="female" />
            Female</label></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td class="leftheading">Country</td>
          <td><select name="country" id="country">
<option value="USA">USA</option>
            <option value="UK">UK</option>
            <option value="China">China</option>
            <option value="Australia">Australia</option>
            <option value="India" selected="selected">India</option>
            <option value="Canada">Canada</option>
            <option value="Others">Others</option>
          </select></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td class="leftheading">Date of Birth</td>
          <td><p>
            <select name="day" id="day">
              <option value="Day">Day</option>
              <?php
			for($i=1;$i<=31;$i++)
			{
				print "<option value='$i'>$i</option>";	
			}
			
			?>
            </select>
            <select name="month" id="month">
              <option value="Month">Month</option>
              <?php
			for($i=1;$i<=12;$i++)
			{
				print "<option value='$i'>$i</option>";	
			}
			
			?>
            </select>
              <select name="year" id="year">
                <option value="Year">Year</option>
                <?php
			for($i=1952;$i<=2015;$i++)
			{
				print "<option value='$i'>$i</option>";	
			}
			
			?>
              </select>
            </p></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td class="leftheading">Profile Picture</td>
          <td><input type="file" name="userpic" id="userpic" /></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><input type="submit" name="submit" id="submit" value="Sign Up" /></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><?php
          if(isset($_POST["submit"]))
		  {
			print $msg;  
		  }
		  
		  ?></td>
          <td>&nbsp;</td>
        </tr>
      </table>
    </form></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>