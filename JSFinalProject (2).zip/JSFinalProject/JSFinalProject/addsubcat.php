<?php
if(!isset($_SESSION))
{
	session_start();
}
?>
<?php
if(!isset($_SESSION["uname"]))
	{
		header("location:error.php");
	}

?>
<?php
if(isset($_POST["submit"]))
{
	$scatnm=$_POST["scname"];
	$maincat=$_POST["cat"];
	$scpic=$_FILES["scpic"]["name"];
	$tname = $_FILES["scpic"]["tmp_name"];
	if($_FILES["scpic"]["error"]==0)
	{
		move_uploaded_file($tname,"userpics/$scpic");
	}
	$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$qry = "insert into addsubcat(scatname,maincatid,subcatpic)values('$scatnm','$maincat','$scpic')";
	$res = mysqli_query($conn,$qry);
	$cnt = mysqli_affected_rows($conn);
	mysqli_close($conn);
	if($cnt==1)
	{
		$msg = "sub Category added successfully";	
	}
	else
	{
		$msg = "sub Category not added successfully";		
	}
}

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="css/home.css">


    <!--bootstrap reference from https://getbootstrap.com/docs/4.4/getting-started/introduction/-->
    <link rel="stylesheet" href="bootstrap/bootstrap/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name= "viewport" content="width=device-width , initial-scale=1.0">
    <title> Lets Buy </title>
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td><?php
	require_once("adminmasterpage.php");
    ?></td>
  </tr>
  <tr>
    <td><h3 align="center">ADD SUBCATEGORY</h3></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div id="d12">
      <form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr><br>
          <td width="148">Subcategory name</td>
          <td width="852"><label for="scname"></label>
            <input type="text" name="scname" id="scname" /></td>
        </tr>
        <tr>
          <td>Choose category</td>
          <td><label for="cat"></label>
            <select name="cat" id="cat">
              <option>select</option><?php
          $conn = mysqli_connect("localhost","root","","myprojdbase")
    		or die(mysqli_connect_error());
		$qry = "select * from addcat";
		$res = mysqli_query($conn,$qry)or die(mysqli_error($conn));
		$cnt = mysqli_affected_rows($conn);
		if($cnt==0)
		{
			print "<option>No Categories Added</option>";
		}
		else
		{
			while($x = mysqli_fetch_array($res))
			{
				print "<option value='$x[0]'>$x[1]</option>";
			}
		}
		mysqli_close($conn);
          
          
          ?>
              
            </select></td>
        </tr>
        <tr>
          <td>Subcategory pic</td>
          <td><label for="scpic"></label>
            <input type="file" name="scpic" id="scpic" /></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><input type="submit" name="submit" id="submit" value="add subcategory" /></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><?php
              if(isset($_POST["submit"]))
			{			
				print $msg;
			}
			?></td>
        </tr>
      </table>
    </form></div></td>
  </tr>
</table>
</body>
</html>