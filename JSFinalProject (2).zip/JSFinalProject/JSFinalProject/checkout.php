<?php
if(!isset($_SESSION))
{
	session_start();	
}

if(isset($_POST["submit"]))
{
	$pmd=$_POST["pmode"];

$cno=$_POST["ccno"];
$nm=$_POST["hname"];
$com=$_POST["company"];
$code=$_POST["code"];
$address=$_POST["saddress"];
$exp = $_POST["expdate"];
$tbill = $_SESSION["tbill"];
$un = $_SESSION["uname"];
	$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$qry="insert into cash(PaymentMode,CreditCardNumber,HolderName,company,expiry,cvvcode,ShippingAddress,totalbill,username) values('$pmd','$cno','$nm','$com','$exp','$code','$address','$tbill','$un')";
	
	$res=mysqli_query($conn,$qry) or die(mysqli_error($conn));
	$count=mysqli_affected_rows($conn);
	mysqli_close($conn);
	header("location:finaorder.php");
}
?>

<!DOCTYPE >
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Lets Buy</title>
<style type="css/home.css">
.homemsg {
	font-family: Arial, Helvetica, sans-serif;
	color: #009;
}
</style>
</head>

<body>
<table width="100%"  cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
    require_once("mainpage.php");
	
	?></td>
  </tr>
  </table>
    <div id="d12"><form id="form1" name="form1" method="post" action="">
    <h3>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspCheckout</h3><br>
      Choose Payment Mode&nbsp&nbsp&nbsp<label>
            <input type="radio" name="pmode" id="cc" value="cc" />
            Credit Card 
            <input type="radio" name="pmode" id="cod" value="cod" />
            Cash on Delivery</label>
        <br>
        <label>Credit Card Number:</label>
            <input type="text" name="ccno" id="ccno" />
          <br>
          <label>&nbsp&nbspCard Holder Name:</label>
            <input type="text" name="hname" id="hname" /><br>
            <label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspCard Company:</label>
            <select name="company" id="company">
              <option value="choose" selected="selected">choose</option>
              <option value="VISA">VISA</option>
              <option value="Master Card">Master Card</option>
            </select>
          </label><br>
        
          <label> &nbsp&nbsp&nbsp&nbsp&nbspCard Expiry Date:</label>
            <input type="text" name="expdate" id="expdate" placeholder="MM/DD"/><br>
          <label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspCard CVV Code:</label>
            <input type="text" name="code" id="code" /><br>
          <label>&nbsp&nbsp&nbspShipping Address:</td></label>
            <textarea name="saddress" id="saddress"></textarea><br> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp &nbsp &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
          <input type="submit" name="submit" id="submit" value="Make Payment" onclick="return valid()" /><br><br><br><br><br>       
		  <?php
		  if(isset($_POST["submit"]))
		  
		  
		  {
			  print " values are submitted";
		  }
	
		  ?>
		  
    </div>

<script type="text/javascript">
function valid()
{
if(document.form1.pmode.value.length<1)
{
 alert("Please select the payment mode")
 return false
 }
if(document.form1.hname.value.length<1)
{
 alert("Please enter the Card holder name")
 return false
 }
 if(document.form1.ccno.value.length<1)
{
 alert("Please enter credit card number")
 return false
 }
 if(document.form1.expdate.value.length<1)
{
 alert("Please enter Expiry date of the card")
 return false
 }
 if(document.form1.code.value.length<1)
{
 alert("Please enter CVV Code")
 return false
 }
 if(document.form1.saddress.value.length<1)
{
 alert("Please enter billing address")
 return false
 }
 
}

</script>
</body>

<footer> follow us on :
            <a href="https://www.facebook.com/rakeshkumar" class="fa fa-facebook"></a>
            <a href="https://www.twitter.com/@rakesh25948380" class="fa fa-twitter"></a>
            <a href="https://www.linkedin.com/in/rakesh-kumar-na-b20b45194/" class="fa fa-linkedin"></a>
            <a href="https://www.instagram.com/?hl=en" class="fa fa-instagram"></a><br>

            &copy; Copyright 2020. All Rights Reserved.<br>

      </footer>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script src="https://use.fontawesome.com/3d7be19efc.js"></script>
</html>