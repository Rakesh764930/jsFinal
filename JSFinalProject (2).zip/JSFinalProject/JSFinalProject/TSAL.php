<?php

if(isset($_POST["s1"]))
{
	$ag = $_POST["age"];
	$sal = $_POST["salary"];
	
	if($ag>=50)
	{
		$bon = (15*$sal)/100;
	}
	else if($ag>=35)
	{
		$bon = (10*$sal)/100;
	}
	else if($ag>=20)
	{
		$bon = (8*$sal)/100;
	}
	else
	{
		$bon=0;
	}
	$tsal = $bon+$sal;
}

?>
<html>
<head>
	<title>Input from User</title>
</head>
<body>
<form name="abc" method="post">
Enter Name <input type="text" name="nm"><br/><br/>
Enter Age <input type="text" name="age"><br/><br/>
Enter Salary <input type="text" name="salary"><br/><br/>
<input type="submit" name="s1" value="Calculate"><br/>
<?php

if(isset($_POST["s1"]))
{
	print "Bonus is $bon<br/>";
	print "Total salary is $tsal";
}

?>
</form>
</body>
</html>

