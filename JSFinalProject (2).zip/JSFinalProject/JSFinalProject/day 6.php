<?php
if(isset($_GET["search"]))
{

$a=$_GET["s"];
$ch = $_GET["r"];
if($ch=="ya")
{
	header("location:http://in.search.yahoo.com/search?p=$a");
}
else if($ch=="u")
{
	header("location:http://www.youtube.com/results?search_query=$a");
}
else if($ch=="b")
{
	header("location:http://www.bing.com/search?q=$a");
}

}

?>



<html>
<head> <title> query string </title> </head>
<body>
<form name="xyz" method="get">
enter search items
<input type="text" name="s"></br>
choose serch engine</br>
<input type="radio" name="r" value="ya">yahoo</br>
<input type="radio" name="r" value="u">u tube</br>
<input type="radio" name="r" value="b">bing</br>
<input type="submit" name="search" value="search"></br>
</form>
</body>
</html>