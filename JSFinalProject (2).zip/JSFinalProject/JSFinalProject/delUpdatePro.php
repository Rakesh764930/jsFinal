<?php
if(!isset($_SESSION))
{
	session_start();
}
?>
<?php
if(!isset($_SESSION["uname"]))
	{
		header("location:error.php");
	}

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="css/home.css">
    <!--bootstrap reference from https://getbootstrap.com/docs/4.4/getting-started/introduction/-->
    <link rel="stylesheet" href="bootstrap/bootstrap/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name= "viewport" content="width=device-width , initial-scale=1.0">
    <title> Lets Buy </title>
<style type="text/css">
.homemsg {
	font-family: Arial, Helvetica, sans-serif;
	color: #009;
}
.lefthead {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.heading {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: 24px;
}
#form1 table tr td h2 {
	color: #303;
}
</style>
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
    require_once("adminmasterpage.php");
	
	?></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td valign="top"><div id="d12"><form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
          <table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td><h2 align="center">Update/Delete Product</h2></td>
              </tr>
            <tr>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td>
              
		<?php
          $conn = mysqli_connect("localhost","root","","myprojdbase")
                    or die(mysqli_connect_error(x));
            $qry = "select * from addproduct";
            $res = mysqli_query($conn,$qry)or die(mysqli_error($conn));
            $cnt = mysqli_affected_rows($conn);
            mysqli_close($conn);
            if($cnt==0)
            {
                print "No Categories added";	
            }
            else
            {
				print "<table width='100%' cellspacing='0' style='background:'>
					 <tr align='left' >
						<th><u>Product Name</u></th>
						<th><u>Product Picture</u></th>
						<th><u>Click to delete/update</u></th>
					 </tr> <br>";
				$eo=0;
                while($x=mysqli_fetch_array($res))
				{
					if($eo==0)
					{	
					print " <tr >
						<td>$x[3]</td>
						<td><a href='delUpdatePro.php?uscid=$x[0]'><img src='userpics/$x[6]' width='125' height='175'></a></td>
						<td>
							<a href='delProd.php?pid=$x[0]' style='text-decoration:none; color:white'>Delete &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</a>
							<a href='updtprod.php?pid=$x[0]' style='text-decoration:none; color:white'>Update</a>						
						</td>
					 </tr>";
					 $eo=1;
					}
					else
					{
					print "<tr >
						<td>$x[3]</td>
						<td><a href='delUpdatePro.php?uscid=$x[0]'><img src='userpics/$x[6]' width='125' height='175'></a><a href='updtdelsubcat.php?scid=$x[0]'></td>
						<td>
							<a href='delProd.php?pid=$x[0]' style='text-decoration:none; color:white'>Delete &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</a>
							<a href='updtprod.php?pid=$x[0]' style='text-decoration:none; color:white'>Update</a>						
						</td>
					 </tr>";
					 $eo=0;
					}
				}
				print "</table>";
            }
        
        ?>

              
              
              </td>
            </tr>
          </table>
        </form></div></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>