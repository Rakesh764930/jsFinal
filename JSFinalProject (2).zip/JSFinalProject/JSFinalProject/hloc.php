<?php
if(isset($_POST["yahoo"]))
{
	header("location:http://www.yahoo.com");
}
else if(isset($_POST["fb"]))
{
	header("location:http://www.facebook.com");
}
else if(isset($_POST["google"]))
{
	header("location:http://www.google.com");
}

?>
<html>
<head><title>Login</title></head>
<body>
<form name="abc" method="post">
<table width=500>
<tr>
	<td>Click on button to visit</td>
	<td>
		<input type="submit" name="yahoo" value="yahoo" >
		<input type="submit" name="fb" value="facebook">
		<input type="submit" name="google" value="google">
	</td>
</tr>
</table>
</form>
</body>
</html>