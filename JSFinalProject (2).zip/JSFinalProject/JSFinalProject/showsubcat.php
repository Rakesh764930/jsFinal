<!DOCTYPE >
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="bootstrap/bootstrap/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" href="css/home.css">
<title>Lets Buy</title>
<style type="text/css">
.homemsg {
	font-family: Arial, Helvetica, sans-serif;
	color: #009;
}
</style>
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
    require_once("mainpage.php");
	    		print "<br><br><br?<br>";

	?></td>
  </tr>
  <tr>
    <td class="homemsg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%" valign="top">
        <?php
        $catid = $_GET["cid"];
		$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$qry = "select * from addsubcat where maincatid=$catid";
	$res = mysqli_query($conn,$qry);
	$cnt = mysqli_affected_rows($conn);
	if($cnt==0)
	{
		print "No Sub Categories";
	}
	else
	{

		print "<div width=100% style='background:green;'>";
		print "<table width=100% style='background:green;'>";		print "<tr align = 'center'>";
				print "<div><h3 align='center'> Sub -Categories </h3></div><br>";

				$cols=1;
				print"<tr align = 'center'>";

		while($x=mysqli_fetch_array($res))
		
		{
			if($cols<=2)
			{

				
print"
<td>
<div class='fluid-container'>
<div class='row' >
  <div class='col-lg-3 col-md-6 col-sm-12'>
	<div class='card '>
	<a href='showprod.php?scid=$x[0]'>
	<img src='userpics/$x[3]' class='card-img-top' alt='Wait'></a>
	  <div class='card-body'>
		<a href='showprod.php?scid=$x[0]' class='btn btn-outline-success'>$x[1]</a>
	  </div>
	</div>

  </div>
  </div>
  </td>";


			// print "<td>
			// <a href='showprod.php?scid=$x[0]'>
			// 	<img src='userpics/$x[3]' width='150' height='175'>
			// </a><br>
			// <a href='showprod.php?scid=$x[0]'>$x[1]</a>
			// </td>";
			$cols++;	
			}
		else
		{
			

			print"
			<td>
<div class='fluid-container'>
<div class='row' >
  <div class='col-lg-3 col-md-6 col-sm-12'>
	<div class='card '>
	<a href='showprod.php?scid=$x[0]'>
	<img src='userpics/$x[3]' class='card-img-top' alt='Wait'></a>
	  <div class='card-body'>
		<a href='showprod.php?scid=$x[0]' class='btn btn-outline-success'>$x[1]</a>
	  </div>
	</div>

  </div>
  </div>
  </td>";


			print "<tr align = 'center'>";
			// <a href='showbrand.php?scid=$x[0]'>
			// 	<img src='userpics/$x[3]' width='150' height='175'></a><br>
			// 	<a href='showbrand.php?scid=$x[0]'>$x[1]</a>
			
			// </td>";
			
			$cols=1;
		}
		}
	}
		print "</table>";
		print "</div>";
		
	
		?></td>
        <td width="30%" align="center">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>

<footer> follow us on :
            <a href="https://www.facebook.com/rakeshkumar" class="fa fa-facebook"></a>
            <a href="https://www.twitter.com/@rakesh25948380" class="fa fa-twitter"></a>
            <a href="https://www.linkedin.com/in/rakesh-kumar-na-b20b45194/" class="fa fa-linkedin"></a>
            <a href="https://www.instagram.com/?hl=en" class="fa fa-instagram"></a><br>
            &copy; Copyright 2020. All Rights Reserved.<br>
      </footer>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script src="https://use.fontawesome.com/3d7be19efc.js"></script>
</body>
</html>