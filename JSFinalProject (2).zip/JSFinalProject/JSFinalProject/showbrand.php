<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.homemsg {
	font-family: Arial, Helvetica, sans-serif;
	color: #009;
}
</style>
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php
    require_once("mainpage.php");
	    		print "<br><br><br?<br>";

	?></td>
  </tr>
  <tr>
    <td class="homemsg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"  align = 'center 'valign="top">
        <?php
       $scid=$_GET["scid"];
		$conn = mysqli_connect("localhost","root","","myprojdbase") 
			or die(mysqli_connect_error());
	$qry = "select addproduct.brand,addbrand.brandname,addbrand.brandpic from addproduct,addbrand where addproduct.brand=addbrand.brandid and addproduct.subcategory=$scid";
	$res = mysqli_query($conn,$qry) or die(mysqli_error($conn));
	$cnt = mysqli_affected_rows($conn);
	if($cnt==0)
	{
		print "No Products";
	}
	else
	{
		print "<table width=100% align ='center'>";
		print "<tr align = 'center'>";
	   print "<div><h3 align='center'> Brands </h3></div><br>";

			
		print "<tr align= 'center'";
		$eo=0;
		while($x=mysqli_fetch_array($res))
		
		{
			if($eo==0)
			{
				
			print "<td>
			<a href='showprod.php?scid=$scid&bid=$x[0]'>
				<img src='userpics/$x[2]' width='150' height='175'>
			</a><br>
			<a href='showprod.php?scid=$scid&bid=$x[0]'>$x[1]</a>
			</td>";
	
			
				
				$eo=1;
			}
		else
		{

			print "<td align = 'center'>";
				print "<td><a href='showprod.php?scid=$scid&bid=$x[0]'>$x[1]</a></td>";
			print "<td>
			<a href='showprod.php?scid=$scid&bid=$x[0]'>
				<img src='userpics/$x[2]' width='150' height='175'>
			</a><br>
			<a href='showprod.php?scid=$scid&bid=$x[0]'>$x[1]</a>
			</td>";
			
		$eo=0;
		}
		}
	}
		print "</table>";
		
	
		?></td>
        <td width="30%" align="center">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>