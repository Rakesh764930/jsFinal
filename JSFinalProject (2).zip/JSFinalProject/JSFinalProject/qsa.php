<?php
if(isset($_POST["sub"]))
{
$a=$_POST["nm"];
$ch=$_POST["search"];
if($ch=="yah")
{
header("location:https://in.search.yahoo.com/search?p=$a");
}
else if($ch=="you")
{
header("location:https://www.search.yahoo.in/search?p=$a");
}
else if($ch=="bing")
{
header("location:https://www.search.yahoo.in/search?p=$a");
}
}

?>
<html>
<head> 
<title>query string assignment</title> 
<body>
<form name="abc" method="post">
enter anything u want to search:
<input type="text" name="nm"><br/>
<input type="radio" name="search" value="yah">yahoo<br/>
<input type="radio" name="search" value="you" >youtube<br/>
<input type="radio" name="search" value="bing" >bing<br/>
<input type="submit" name="sub" value= "submit">
</form></body>
</head>
</html>
